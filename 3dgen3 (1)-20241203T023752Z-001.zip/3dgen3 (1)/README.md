to launch the system find 
"C:\Users\(replace this with your username)\Downloads\3dgen3\src\minecraft.html"
